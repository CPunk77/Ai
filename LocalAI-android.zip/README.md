# Local AI (Android)
1. Загрузите проект в GitHub, вкладка Actions → Build APK → скачайте LocalAI-apk.
   Или откройте папку в Android Studio: Build → Build APK(s).
2. Скачайте модель Gemma 2B IT (cpu int4) для MediaPipe LLM Inference (Kaggle / Hugging Face).
3. В приложении нажмите «Модель» и выберите файл.
