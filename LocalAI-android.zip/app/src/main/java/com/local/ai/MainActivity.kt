package com.local.ai

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File

const val DEFAULT_PROMPT = "Ты локальный ИИ-ассистент премиум-уровня. Отвечай по-русски, " +
    "точно, структурированно и без воды. Если не уверен, так и скажи."

data class Msg(val role: String, val text: String, val fb: Int = 0) // fb: 1 хорошо, -1 плохо

class VM(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("ai", Context.MODE_PRIVATE)
    private val modelFile = File(app.filesDir, "model.task")
    private var llm: LlmInference? = null
    private var onToken: (String, Boolean) -> Unit = { _, _ -> }

    val msgs = mutableStateListOf<Msg>()
    var busy by mutableStateOf(false)
    var prompt by mutableStateOf(sp.getString("prompt", DEFAULT_PROMPT) ?: DEFAULT_PROMPT)
    var status by mutableStateOf(
        if (modelFile.exists()) "Загрузка модели…" else "Выберите файл модели (.task / .bin)"
    )

    fun load() = viewModelScope.launch(Dispatchers.Default) {
        if (!modelFile.exists() || llm != null) return@launch
        try {
            val o = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(1024)
                .setResultListener { part, done -> onToken(part, done) }
                .build()
            llm = LlmInference.createFromOptions(getApplication(), o)
            status = "Готово · работает офлайн"
        } catch (e: Exception) {
            status = "Ошибка: ${e.message}"
        }
    }

    fun importModel(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        status = "Копирую модель…"
        llm = null
        getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i ->
            modelFile.outputStream().use { i.copyTo(it) }
        }
        load()
    }

    private fun build(): String {
        val sb = StringBuilder()
        var first = true
        for (m in msgs.filter { it.text.isNotBlank() }.takeLast(7)) {
            if (m.role == "user") {
                sb.append("<start_of_turn>user\n")
                if (first) { sb.append(prompt).append("\n\n"); first = false }
                sb.append(m.text).append("<end_of_turn>\n")
            } else {
                sb.append("<start_of_turn>model\n").append(m.text).append("<end_of_turn>\n")
            }
        }
        return sb.append("<start_of_turn>model\n").toString()
    }

    fun send(text: String) {
        val m = llm ?: return
        if (busy || text.isBlank()) return
        msgs.add(Msg("user", text))
        val p = build()
        msgs.add(Msg("assistant", ""))
        val idx = msgs.lastIndex
        busy = true
        onToken = { part, done ->
            viewModelScope.launch(Dispatchers.Main) {
                msgs[idx] = msgs[idx].copy(text = msgs[idx].text + part)
                if (done) busy = false
            }
        }
        viewModelScope.launch(Dispatchers.Default) {
            try { m.generateResponseAsync(p) }
            catch (e: Exception) { busy = false; status = "Ошибка: ${e.message}" }
        }
    }

    fun rate(i: Int, v: Int) { msgs[i] = msgs[i].copy(fb = v) }

    /** Самоулучшение: модель переписывает свой промпт по плохим ответам. Откат доступен. */
    fun improve() {
        val m = llm ?: return
        val bad = msgs.indices.filter { msgs[it].fb == -1 && it > 0 }
            .map { "Вопрос: ${msgs[it - 1].text}\nОтвет: ${msgs[it].text.take(300)}" }
        if (bad.isEmpty()) { status = "Отметьте плохие ответы 👎"; return }
        busy = true
        status = "Улучшаю себя…"
        viewModelScope.launch(Dispatchers.Default) {
            val ask = "<start_of_turn>user\nТы улучшаешь системный промпт ИИ-ассистента.\n" +
                "Текущий промпт:\n$prompt\n\nПользователь отметил эти ответы как плохие:\n" +
                bad.joinToString("\n---\n") +
                "\n\nНапиши улучшенный промпт с общими правилами. Верни только текст промпта." +
                "<end_of_turn>\n<start_of_turn>model\n"
            val new = try { m.generateResponse(ask).trim() } catch (e: Exception) { "" }
            if (new.length > 20) {
                val v = JSONArray(sp.getString("v", "[]")).put(prompt)
                sp.edit().putString("prompt", new).putString("v", v.toString()).apply()
                prompt = new
                status = "Промпт обновлён · можно откатить"
            } else status = "Не получилось, попробуйте ещё раз"
            busy = false
        }
    }

    fun rollback() {
        val v = JSONArray(sp.getString("v", "[]"))
        if (v.length() == 0) { status = "Нет прошлых версий"; return }
        prompt = v.getString(v.length() - 1)
        v.remove(v.length() - 1)
        sp.edit().putString("prompt", prompt).putString("v", v.toString()).apply()
        status = "Откат выполнен"
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF7C5CFF),
                    background = Color(0xFF0B0D12),
                    surface = Color(0xFF171A22)
                )
            ) { Screen() }
        }
    }
}

@Composable
fun Screen(vm: VM = viewModel()) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importModel(it) }
    }
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(Unit) { vm.load() }
    LaunchedEffect(vm.msgs.size, vm.msgs.lastOrNull()?.text) {
        if (vm.msgs.isNotEmpty()) list.animateScrollToItem(vm.msgs.lastIndex)
    }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Local AI", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text(vm.status, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            TextButton({ pick.launch(arrayOf("*/*")) }) { Text("Модель") }
        }
        Row {
            TextButton({ vm.improve() }, enabled = !vm.busy) { Text("✨ Улучшить себя") }
            TextButton({ vm.rollback() }) { Text("↩ Откат") }
            TextButton({ vm.msgs.clear() }) { Text("Очистить") }
        }
        LazyColumn(
            Modifier.weight(1f), state = list,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(vm.msgs) { i, m -> Bubble(m) { vm.rate(i, it) } }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text("Сообщение…") },
                shape = RoundedCornerShape(24.dp), maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            Button({ vm.send(input); input = "" }, enabled = !vm.busy) { Text("→") }
        }
    }
}

@Composable
fun Bubble(m: Msg, rate: (Int) -> Unit) {
    val me = m.role == "user"
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (me) Alignment.End else Alignment.Start
    ) {
        Text(
            m.text.ifBlank { "…" }, color = Color.White,
            modifier = Modifier.widthIn(max = 300.dp)
                .background(if (me) Color(0xFF7C5CFF) else Color(0xFF171A22), RoundedCornerShape(18.dp))
                .padding(12.dp)
        )
        if (!me && m.text.isNotBlank()) Row {
            TextButton({ rate(1) }) { Text(if (m.fb == 1) "👍 ✓" else "👍") }
            TextButton({ rate(-1) }) { Text(if (m.fb == -1) "👎 ✓" else "👎") }
        }
    }
}
